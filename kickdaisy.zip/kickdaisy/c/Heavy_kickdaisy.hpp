/**
 * Copyright (c) 2020 Enzien Audio, Ltd.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions, and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the phrase "powered by heavy",
 *    the heavy logo, and a hyperlink to https://enzienaudio.com, all in a visible
 *    form.
 * 
 *   2.1 If the Application is distributed in a store system (for example,
 *       the Apple "App Store" or "Google Play"), the phrase "powered by heavy"
 *       shall be included in the app description or the copyright text as well as
 *       the in the app itself. The heavy logo will shall be visible in the app
 *       itself as well.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

#ifndef _HEAVY_CONTEXT_KICKDAISY_HPP_
#define _HEAVY_CONTEXT_KICKDAISY_HPP_

// object includes
#include "HeavyContext.hpp"
#include "HvControlPack.h"
#include "HvSignalLine.h"
#include "HvControlBinop.h"
#include "HvControlVar.h"
#include "HvControlSystem.h"
#include "HvSignalVar.h"
#include "HvSignalPhasor.h"
#include "HvControlDelay.h"
#include "HvMath.h"
#include "HvSignalRPole.h"
#include "HvControlCast.h"
#include "HvSignalDel1.h"

class Heavy_kickdaisy : public HeavyContext {

 public:
  Heavy_kickdaisy(double sampleRate, int poolKb=10, int inQueueKb=2, int outQueueKb=0);
  ~Heavy_kickdaisy();

  const char *getName() override { return "kickdaisy"; }
  int getNumInputChannels() override { return 0; }
  int getNumOutputChannels() override { return 2; }

  int process(float **inputBuffers, float **outputBuffer, int n) override;
  int processInline(float *inputBuffers, float *outputBuffer, int n) override;
  int processInlineInterleaved(float *inputBuffers, float *outputBuffer, int n) override;

  int getParameterInfo(int index, HvParameterInfo *info) override;
  struct Parameter {
    struct In {
      enum ParameterIn : hv_uint32_t {
        BUTTON1 = 0xB4D78F23, // Button1
        BUTTON2 = 0x3FE62CA, // Button2
        ENCODER = 0x39ADE514, // Encoder
        KNOB1 = 0x62DD3F82, // Knob1
        KNOB2 = 0x6BE4E001, // Knob2
      };
    };
  };

 private:
  HvTable *getTableForHash(hv_uint32_t tableHash) override;
  void scheduleMessageForReceiver(hv_uint32_t receiverHash, HvMessage *m) override;

  // static sendMessage functions
  static void cVar_NvwNX8kJ_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_olKXlU0d_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_BmiQm1vn_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_no3BbprJ_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_iLue5QlJ_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_q5QF1hVG_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_h39eYHOh_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_VZOwTwt2_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_X3aczEul_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_ylaj6x4M_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_KBuhISrH_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_hehk0wd8_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_AyOLZXaP_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_A6FvTiy4_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_bILoWdVy_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_fCmLp9QK_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_T2hO66Tg_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_qupyOTUc_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_1l2oS9Kt_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_PG1mK3q2_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_u8gDAcaP_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSystem_aYQkucnI_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSwitchcase_Hf6zuQ4R_onMessage(HeavyContextInterface *, void *, int letIn, const HvMessage *const, void *);
  static void cCast_hXaatIvf_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_elHoHsOb_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cDelay_GYpFbLac_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_pO9HE0M8_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cPack_2MhvddCb_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_aG5K7LMj_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_zxEqQcCp_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_ZcAprHXR_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_14DFN8lv_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_eol3Hhva_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_hPiFQeou_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cPack_Jjqd07GE_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_dvI2xwm7_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_XwolqAcg_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_5VuGgmK9_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cSwitchcase_PUP2bKOY_onMessage(HeavyContextInterface *, void *, int letIn, const HvMessage *const, void *);
  static void cDelay_NSsFGi63_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_CqM7t59s_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_Jth1ANyg_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_M4c9nSRh_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_ETmlUpzU_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cCast_qbcn11JV_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cReceive_LtNgOs7l_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cBinop_6Waf0O7N_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cMsg_HDENviYB_sendMessage(HeavyContextInterface *, int, const HvMessage *);
  static void cVar_Hux1Qan8_sendMessage(HeavyContextInterface *, int, const HvMessage *);

  // objects
  SignalLine sLine_QajiopOH;
  SignalPhasor sPhasor_m87X0rNm;
  SignalRPole sRPole_yCMXCsSr;
  SignalLine sLine_1BHQa88z;
  ControlVar cVar_NvwNX8kJ;
  ControlBinop cBinop_olKXlU0d;
  ControlBinop cBinop_BmiQm1vn;
  ControlBinop cBinop_no3BbprJ;
  ControlBinop cBinop_q5QF1hVG;
  ControlBinop cBinop_h39eYHOh;
  ControlVar cVar_AyOLZXaP;
  SignalVarf sVarf_LZ3emC9f;
  SignalVarf sVarf_35a48ADo;
  SignalVarf sVarf_1hE7kTUl;
  ControlVar cVar_A6FvTiy4;
  ControlBinop cBinop_bILoWdVy;
  ControlBinop cBinop_fCmLp9QK;
  ControlBinop cBinop_T2hO66Tg;
  ControlBinop cBinop_qupyOTUc;
  ControlBinop cBinop_PG1mK3q2;
  SignalVarf sVarf_1TlhfSSA;
  ControlDelay cDelay_GYpFbLac;
  ControlPack cPack_2MhvddCb;
  ControlBinop cBinop_zxEqQcCp;
  ControlBinop cBinop_eol3Hhva;
  ControlPack cPack_Jjqd07GE;
  ControlDelay cDelay_NSsFGi63;
  SignalVarf sVarf_uTu4tArf;
  SignalVarf sVarf_7aNJeyBk;
  ControlVar cVar_Jth1ANyg;
  ControlBinop cBinop_6Waf0O7N;
  ControlVar cVar_Hux1Qan8;
};

#endif // _HEAVY_CONTEXT_KICKDAISY_HPP_
