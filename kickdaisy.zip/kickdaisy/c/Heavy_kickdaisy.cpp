/**
 * Copyright (c) 2020 Enzien Audio, Ltd.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions, and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the phrase "powered by heavy",
 *    the heavy logo, and a hyperlink to https://enzienaudio.com, all in a visible
 *    form.
 * 
 *   2.1 If the Application is distributed in a store system (for example,
 *       the Apple "App Store" or "Google Play"), the phrase "powered by heavy"
 *       shall be included in the app description or the copyright text as well as
 *       the in the app itself. The heavy logo will shall be visible in the app
 *       itself as well.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

#include "Heavy_kickdaisy.hpp"

#define Context(_c) reinterpret_cast<Heavy_kickdaisy *>(_c)



/*
 * C Functions
 */

extern "C" {
  HV_EXPORT HeavyContextInterface *hv_kickdaisy_new(double sampleRate) {
    return new Heavy_kickdaisy(sampleRate);
  }

  HV_EXPORT HeavyContextInterface *hv_kickdaisy_new_with_options(double sampleRate,
      int poolKb, int inQueueKb, int outQueueKb) {
    return new Heavy_kickdaisy(sampleRate, poolKb, inQueueKb, outQueueKb);
  }
} // extern "C"







/*
 * Class Functions
 */

Heavy_kickdaisy::Heavy_kickdaisy(double sampleRate, int poolKb, int inQueueKb, int outQueueKb)
    : HeavyContext(sampleRate, poolKb, inQueueKb, outQueueKb) {
  numBytes += sLine_init(&sLine_QajiopOH);
  numBytes += sPhasor_init(&sPhasor_m87X0rNm, sampleRate);
  numBytes += sRPole_init(&sRPole_yCMXCsSr);
  numBytes += sLine_init(&sLine_1BHQa88z);
  numBytes += cVar_init_f(&cVar_NvwNX8kJ, 1.0f);
  numBytes += cBinop_init(&cBinop_h39eYHOh, 0.0f); // __add
  numBytes += cVar_init_f(&cVar_AyOLZXaP, 0.0f);
  numBytes += sVarf_init(&sVarf_LZ3emC9f, 200.0f, 0.0f, false);
  numBytes += sVarf_init(&sVarf_35a48ADo, 0.0f, 0.0f, false);
  numBytes += sVarf_init(&sVarf_1hE7kTUl, 0.0f, 0.0f, false);
  numBytes += cVar_init_f(&cVar_A6FvTiy4, 1000.0f);
  numBytes += cBinop_init(&cBinop_PG1mK3q2, 0.0f); // __mul
  numBytes += sVarf_init(&sVarf_1TlhfSSA, 2.0f, 0.0f, false);
  numBytes += cDelay_init(this, &cDelay_GYpFbLac, 10.0f);
  numBytes += cPack_init(&cPack_2MhvddCb, 2, 0.0f, 500.0f);
  numBytes += cPack_init(&cPack_Jjqd07GE, 2, 0.0f, 500.0f);
  numBytes += cDelay_init(this, &cDelay_NSsFGi63, 10.0f);
  numBytes += sVarf_init(&sVarf_uTu4tArf, 2.0f, 0.0f, false);
  numBytes += sVarf_init(&sVarf_7aNJeyBk, 0.0f, 0.0f, false);
  numBytes += cVar_init_f(&cVar_Jth1ANyg, 0.0f);
  numBytes += cVar_init_f(&cVar_Hux1Qan8, 0.0f);
  
  // schedule a message to trigger all loadbangs via the __hv_init receiver
  scheduleMessageForReceiver(0xCE5CC65B, msg_initWithBang(HV_MESSAGE_ON_STACK(1), 0));
}

Heavy_kickdaisy::~Heavy_kickdaisy() {
  cPack_free(&cPack_2MhvddCb);
  cPack_free(&cPack_Jjqd07GE);
}

HvTable *Heavy_kickdaisy::getTableForHash(hv_uint32_t tableHash) {
  return nullptr;
}

void Heavy_kickdaisy::scheduleMessageForReceiver(hv_uint32_t receiverHash, HvMessage *m) {
  switch (receiverHash) {
    case 0xB4D78F23: { // Button1
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_14DFN8lv_sendMessage);
      break;
    }
    case 0x3FE62CA: { // Button2
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_hPiFQeou_sendMessage);
      break;
    }
    case 0x39ADE514: { // Encoder
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_ETmlUpzU_sendMessage);
      break;
    }
    case 0x62DD3F82: { // Knob1
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_X3aczEul_sendMessage);
      break;
    }
    case 0x6BE4E001: { // Knob2
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_LtNgOs7l_sendMessage);
      break;
    }
    case 0xCE5CC65B: { // __hv_init
      mq_addMessageByTimestamp(&mq, m, 0, &cReceive_ZcAprHXR_sendMessage);
      break;
    }
    default: return;
  }
}

int Heavy_kickdaisy::getParameterInfo(int index, HvParameterInfo *info) {
  if (info != nullptr) {
    switch (index) {
      case 0: {
        info->name = "Knob1";
        info->hash = 0x62DD3F82;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.0f;
        info->maxVal = 1.0f;
        info->defaultVal = 0.5f;
        break;
      }
      case 1: {
        info->name = "Button2";
        info->hash = 0x3FE62CA;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.0f;
        info->maxVal = 1.0f;
        info->defaultVal = 0.5f;
        break;
      }
      case 2: {
        info->name = "Button1";
        info->hash = 0xB4D78F23;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.0f;
        info->maxVal = 1.0f;
        info->defaultVal = 0.5f;
        break;
      }
      case 3: {
        info->name = "Knob2";
        info->hash = 0x6BE4E001;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.0f;
        info->maxVal = 1.0f;
        info->defaultVal = 0.5f;
        break;
      }
      case 4: {
        info->name = "Encoder";
        info->hash = 0x39ADE514;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.0f;
        info->maxVal = 1.0f;
        info->defaultVal = 0.5f;
        break;
      }
      default: {
        info->name = "invalid parameter index";
        info->hash = 0;
        info->type = HvParameterType::HV_PARAM_TYPE_PARAMETER_IN;
        info->minVal = 0.0f;
        info->maxVal = 0.0f;
        info->defaultVal = 0.0f;
        break;
      }
    }
  }
  return 5;
}



/*
 * Send Function Implementations
 */


void Heavy_kickdaisy::cVar_NvwNX8kJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_EQ, 0.0f, 0, m, &cBinop_olKXlU0d_sendMessage);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 5000.0f, 0, m, &cBinop_no3BbprJ_sendMessage);
}

void Heavy_kickdaisy::cBinop_olKXlU0d_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_NvwNX8kJ, 1, m, &cVar_NvwNX8kJ_sendMessage);
}

void Heavy_kickdaisy::cBinop_BmiQm1vn_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 20.0f, 0, m, &cBinop_eol3Hhva_sendMessage);
}

void Heavy_kickdaisy::cBinop_no3BbprJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_ADD, 1000.0f, 0, m, &cBinop_q5QF1hVG_sendMessage);
}

void Heavy_kickdaisy::cMsg_iLue5QlJ_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 3.0f);
  sVarf_onMessage(_c, &Context(_c)->sVarf_1TlhfSSA, m);
}

void Heavy_kickdaisy::cBinop_q5QF1hVG_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_A6FvTiy4, 0, m, &cVar_A6FvTiy4_sendMessage);
}

void Heavy_kickdaisy::cBinop_h39eYHOh_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_Jth1ANyg, 0, m, &cVar_Jth1ANyg_sendMessage);
  cVar_onMessage(_c, &Context(_c)->cVar_Hux1Qan8, 0, m, &cVar_Hux1Qan8_sendMessage);
}

void Heavy_kickdaisy::cMsg_VZOwTwt2_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 0.0f);
  cVar_onMessage(_c, &Context(_c)->cVar_Jth1ANyg, 0, m, &cVar_Jth1ANyg_sendMessage);
}

void Heavy_kickdaisy::cReceive_X3aczEul_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 300.0f, 0, m, &cBinop_zxEqQcCp_sendMessage);
}

void Heavy_kickdaisy::cCast_ylaj6x4M_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cVar_onMessage(_c, &Context(_c)->cVar_NvwNX8kJ, 0, m, &cVar_NvwNX8kJ_sendMessage);
}

void Heavy_kickdaisy::cMsg_KBuhISrH_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 25.0f, 0, m, &cBinop_6Waf0O7N_sendMessage);
}

void Heavy_kickdaisy::cMsg_hehk0wd8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 200.0f);
  cPack_onMessage(_c, &Context(_c)->cPack_2MhvddCb, 1, m, &cPack_2MhvddCb_sendMessage);
}

void Heavy_kickdaisy::cVar_AyOLZXaP_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 300.0f, 0, m, &cBinop_zxEqQcCp_sendMessage);
}

void Heavy_kickdaisy::cVar_A6FvTiy4_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_PG1mK3q2, HV_BINOP_MULTIPLY, 0, m, &cBinop_PG1mK3q2_sendMessage);
}

void Heavy_kickdaisy::cBinop_bILoWdVy_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MAX, 0.0f, 0, m, &cBinop_fCmLp9QK_sendMessage);
}

void Heavy_kickdaisy::cBinop_fCmLp9QK_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_SUBTRACT, 1.0f, 0, m, &cBinop_T2hO66Tg_sendMessage);
  sVarf_onMessage(_c, &Context(_c)->sVarf_1hE7kTUl, m);
}

void Heavy_kickdaisy::cBinop_T2hO66Tg_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  sVarf_onMessage(_c, &Context(_c)->sVarf_35a48ADo, m);
}

void Heavy_kickdaisy::cBinop_qupyOTUc_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_PG1mK3q2, HV_BINOP_MULTIPLY, 1, m, &cBinop_PG1mK3q2_sendMessage);
}

void Heavy_kickdaisy::cMsg_1l2oS9Kt_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 6.28319f);
  msg_setElementToFrom(m, 1, n, 0);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_DIVIDE, 0.0f, 0, m, &cBinop_qupyOTUc_sendMessage);
}

void Heavy_kickdaisy::cBinop_PG1mK3q2_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MIN, 1.0f, 0, m, &cBinop_bILoWdVy_sendMessage);
}

void Heavy_kickdaisy::cMsg_u8gDAcaP_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "samplerate");
  cSystem_onMessage(_c, NULL, 0, m, &cSystem_aYQkucnI_sendMessage);
}

void Heavy_kickdaisy::cSystem_aYQkucnI_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_1l2oS9Kt_sendMessage(_c, 0, m);
}

void Heavy_kickdaisy::cSwitchcase_Hf6zuQ4R_onMessage(HeavyContextInterface *_c, void *o, int letIn, const HvMessage *const m, void *sendMessage) {
  switch (msg_getHash(m, 0)) {
    case 0x7A5B032D: { // "stop"
      cMsg_elHoHsOb_sendMessage(_c, 0, m);
      break;
    }
    default: {
      cMsg_elHoHsOb_sendMessage(_c, 0, m);
      cDelay_onMessage(_c, &Context(_c)->cDelay_GYpFbLac, 1, m, &cDelay_GYpFbLac_sendMessage);
      cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_hXaatIvf_sendMessage);
      break;
    }
  }
}

void Heavy_kickdaisy::cCast_hXaatIvf_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cDelay_onMessage(_c, &Context(_c)->cDelay_GYpFbLac, 0, m, &cDelay_GYpFbLac_sendMessage);
}

void Heavy_kickdaisy::cMsg_elHoHsOb_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "clear");
  cDelay_onMessage(_c, &Context(_c)->cDelay_GYpFbLac, 0, m, &cDelay_GYpFbLac_sendMessage);
}

void Heavy_kickdaisy::cDelay_GYpFbLac_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const m) {
  cDelay_clearExecutingMessage(&Context(_c)->cDelay_GYpFbLac, m);
  cPack_onMessage(_c, &Context(_c)->cPack_2MhvddCb, 0, m, &cPack_2MhvddCb_sendMessage);
}

void Heavy_kickdaisy::cMsg_pO9HE0M8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setFloat(m, 1, 5.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_QajiopOH, 0, m, NULL);
}

void Heavy_kickdaisy::cPack_2MhvddCb_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  sLine_onMessage(_c, &Context(_c)->sLine_QajiopOH, 0, m, NULL);
}

void Heavy_kickdaisy::cCast_aG5K7LMj_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_pO9HE0M8_sendMessage(_c, 0, m);
  cSwitchcase_Hf6zuQ4R_onMessage(_c, NULL, 0, m, NULL);
}

void Heavy_kickdaisy::cBinop_zxEqQcCp_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  sVarf_onMessage(_c, &Context(_c)->sVarf_7aNJeyBk, m);
}

void Heavy_kickdaisy::cReceive_ZcAprHXR_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_u8gDAcaP_sendMessage(_c, 0, m);
  cVar_onMessage(_c, &Context(_c)->cVar_A6FvTiy4, 0, m, &cVar_A6FvTiy4_sendMessage);
  cMsg_hehk0wd8_sendMessage(_c, 0, m);
  cMsg_iLue5QlJ_sendMessage(_c, 0, m);
  cMsg_HDENviYB_sendMessage(_c, 0, m);
  cMsg_VZOwTwt2_sendMessage(_c, 0, m);
}

void Heavy_kickdaisy::cReceive_14DFN8lv_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_qbcn11JV_sendMessage);
}

void Heavy_kickdaisy::cBinop_eol3Hhva_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cPack_onMessage(_c, &Context(_c)->cPack_Jjqd07GE, 1, m, &cPack_Jjqd07GE_sendMessage);
}

void Heavy_kickdaisy::cReceive_hPiFQeou_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_ylaj6x4M_sendMessage);
}

void Heavy_kickdaisy::cPack_Jjqd07GE_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  sLine_onMessage(_c, &Context(_c)->sLine_1BHQa88z, 0, m, NULL);
}

void Heavy_kickdaisy::cCast_dvI2xwm7_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cMsg_CqM7t59s_sendMessage(_c, 0, m);
  cSwitchcase_PUP2bKOY_onMessage(_c, NULL, 0, m, NULL);
}

void Heavy_kickdaisy::cMsg_XwolqAcg_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setSymbol(m, 0, "clear");
  cDelay_onMessage(_c, &Context(_c)->cDelay_NSsFGi63, 0, m, &cDelay_NSsFGi63_sendMessage);
}

void Heavy_kickdaisy::cCast_5VuGgmK9_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cDelay_onMessage(_c, &Context(_c)->cDelay_NSsFGi63, 0, m, &cDelay_NSsFGi63_sendMessage);
}

void Heavy_kickdaisy::cSwitchcase_PUP2bKOY_onMessage(HeavyContextInterface *_c, void *o, int letIn, const HvMessage *const m, void *sendMessage) {
  switch (msg_getHash(m, 0)) {
    case 0x7A5B032D: { // "stop"
      cMsg_XwolqAcg_sendMessage(_c, 0, m);
      break;
    }
    default: {
      cMsg_XwolqAcg_sendMessage(_c, 0, m);
      cDelay_onMessage(_c, &Context(_c)->cDelay_NSsFGi63, 1, m, &cDelay_NSsFGi63_sendMessage);
      cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_5VuGgmK9_sendMessage);
      break;
    }
  }
}

void Heavy_kickdaisy::cDelay_NSsFGi63_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const m) {
  cDelay_clearExecutingMessage(&Context(_c)->cDelay_NSsFGi63, m);
  cPack_onMessage(_c, &Context(_c)->cPack_Jjqd07GE, 0, m, &cPack_Jjqd07GE_sendMessage);
}

void Heavy_kickdaisy::cMsg_CqM7t59s_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(2);
  msg_init(m, 2, msg_getTimestamp(n));
  msg_setFloat(m, 0, 1.0f);
  msg_setFloat(m, 1, 5.0f);
  sLine_onMessage(_c, &Context(_c)->sLine_1BHQa88z, 0, m, NULL);
}

void Heavy_kickdaisy::cVar_Jth1ANyg_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_h39eYHOh, HV_BINOP_ADD, 1, m, &cBinop_h39eYHOh_sendMessage);
}

void Heavy_kickdaisy::cMsg_M4c9nSRh_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, -1.0f);
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 25.0f, 0, m, &cBinop_6Waf0O7N_sendMessage);
}

void Heavy_kickdaisy::cReceive_ETmlUpzU_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 25.0f, 0, m, &cBinop_6Waf0O7N_sendMessage);
}

void Heavy_kickdaisy::cCast_qbcn11JV_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_aG5K7LMj_sendMessage);
  cCast_onMessage(_c, HV_CAST_BANG, 0, m, &cCast_dvI2xwm7_sendMessage);
}

void Heavy_kickdaisy::cReceive_LtNgOs7l_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_k_onMessage(_c, NULL, HV_BINOP_MULTIPLY, 2000.0f, 0, m, &cBinop_BmiQm1vn_sendMessage);
}

void Heavy_kickdaisy::cBinop_6Waf0O7N_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  cBinop_onMessage(_c, &Context(_c)->cBinop_h39eYHOh, HV_BINOP_ADD, 0, m, &cBinop_h39eYHOh_sendMessage);
}

void Heavy_kickdaisy::cMsg_HDENviYB_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *const n) {
  HvMessage *m = nullptr;
  m = HV_MESSAGE_ON_STACK(1);
  msg_init(m, 1, msg_getTimestamp(n));
  msg_setFloat(m, 0, 3.0f);
  sVarf_onMessage(_c, &Context(_c)->sVarf_uTu4tArf, m);
}

void Heavy_kickdaisy::cVar_Hux1Qan8_sendMessage(HeavyContextInterface *_c, int letIn, const HvMessage *m) {
  sVarf_onMessage(_c, &Context(_c)->sVarf_LZ3emC9f, m);
}




/*
 * Context Process Implementation
 */

int Heavy_kickdaisy::process(float **inputBuffers, float **outputBuffers, int n) {
  while (hLp_hasData(&inQueue)) {
    hv_uint32_t numBytes = 0;
    ReceiverMessagePair *p = reinterpret_cast<ReceiverMessagePair *>(hLp_getReadBuffer(&inQueue, &numBytes));
    hv_assert(numBytes >= sizeof(ReceiverMessagePair));
    scheduleMessageForReceiver(p->receiverHash, &p->msg);
    hLp_consume(&inQueue);
  }
  const int n4 = n & ~HV_N_SIMD_MASK; // ensure that the block size is a multiple of HV_N_SIMD

  // temporary signal vars
  hv_bufferf_t Bf0, Bf1, Bf2, Bf3, Bf4;

  // input and output vars
  hv_bufferf_t O0, O1;

  // declare and init the zero buffer
  hv_bufferf_t ZERO; __hv_zero_f(VOf(ZERO));

  hv_uint32_t nextBlock = blockStartTimestamp;
  for (int n = 0; n < n4; n += HV_N_SIMD) {

    // process all of the messages for this block
    nextBlock += HV_N_SIMD;
    while (mq_hasMessageBefore(&mq, nextBlock)) {
      MessageNode *const node = mq_peek(&mq);
      node->sendMessage(this, node->let, node->m);
      mq_pop(&mq);
    }

    

    // zero output buffers
    __hv_zero_f(VOf(O0));
    __hv_zero_f(VOf(O1));

    // process all signal functions
    __hv_line_f(&sLine_QajiopOH, VOf(Bf0));
    __hv_varread_f(&sVarf_1TlhfSSA, VOf(Bf1));
    __hv_pow_f(VIf(Bf0), VIf(Bf1), VOf(Bf1));
    __hv_varread_f(&sVarf_LZ3emC9f, VOf(Bf0));
    __hv_varread_f(&sVarf_7aNJeyBk, VOf(Bf2));
    __hv_fma_f(VIf(Bf1), VIf(Bf0), VIf(Bf2), VOf(Bf2));
    __hv_phasor_f(&sPhasor_m87X0rNm, VIf(Bf2), VOf(Bf2));
    __hv_var_k_f(VOf(Bf0), 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f);
    __hv_sub_f(VIf(Bf2), VIf(Bf0), VOf(Bf0));
    __hv_abs_f(VIf(Bf0), VOf(Bf0));
    __hv_var_k_f(VOf(Bf2), 0.25f, 0.25f, 0.25f, 0.25f, 0.25f, 0.25f, 0.25f, 0.25f);
    __hv_sub_f(VIf(Bf0), VIf(Bf2), VOf(Bf2));
    __hv_var_k_f(VOf(Bf0), 6.28318530718f, 6.28318530718f, 6.28318530718f, 6.28318530718f, 6.28318530718f, 6.28318530718f, 6.28318530718f, 6.28318530718f);
    __hv_mul_f(VIf(Bf2), VIf(Bf0), VOf(Bf0));
    __hv_mul_f(VIf(Bf0), VIf(Bf0), VOf(Bf2));
    __hv_mul_f(VIf(Bf0), VIf(Bf2), VOf(Bf1));
    __hv_mul_f(VIf(Bf1), VIf(Bf2), VOf(Bf2));
    __hv_var_k_f(VOf(Bf3), 0.00783333333333f, 0.00783333333333f, 0.00783333333333f, 0.00783333333333f, 0.00783333333333f, 0.00783333333333f, 0.00783333333333f, 0.00783333333333f);
    __hv_var_k_f(VOf(Bf4), -0.166666666667f, -0.166666666667f, -0.166666666667f, -0.166666666667f, -0.166666666667f, -0.166666666667f, -0.166666666667f, -0.166666666667f);
    __hv_fma_f(VIf(Bf1), VIf(Bf4), VIf(Bf0), VOf(Bf0));
    __hv_fma_f(VIf(Bf2), VIf(Bf3), VIf(Bf0), VOf(Bf0));
    __hv_var_k_f(VOf(Bf3), 8.0f, 8.0f, 8.0f, 8.0f, 8.0f, 8.0f, 8.0f, 8.0f);
    __hv_mul_f(VIf(Bf0), VIf(Bf3), VOf(Bf3));
    __hv_var_k_f(VOf(Bf0), 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f);
    __hv_min_f(VIf(Bf3), VIf(Bf0), VOf(Bf0));
    __hv_var_k_f(VOf(Bf3), -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f);
    __hv_max_f(VIf(Bf0), VIf(Bf3), VOf(Bf3));
    __hv_varread_f(&sVarf_1hE7kTUl, VOf(Bf0));
    __hv_mul_f(VIf(Bf3), VIf(Bf0), VOf(Bf0));
    __hv_varread_f(&sVarf_35a48ADo, VOf(Bf3));
    __hv_rpole_f(&sRPole_yCMXCsSr, VIf(Bf0), VIf(Bf3), VOf(Bf3));
    __hv_line_f(&sLine_1BHQa88z, VOf(Bf0));
    __hv_varread_f(&sVarf_uTu4tArf, VOf(Bf2));
    __hv_pow_f(VIf(Bf0), VIf(Bf2), VOf(Bf2));
    __hv_mul_f(VIf(Bf3), VIf(Bf2), VOf(Bf2));
    __hv_add_f(VIf(Bf2), VIf(O0), VOf(O0));
    __hv_add_f(VIf(Bf2), VIf(O1), VOf(O1));

    // save output vars to output buffer
    __hv_store_f(outputBuffers[0]+n, VIf(O0));
    __hv_store_f(outputBuffers[1]+n, VIf(O1));
  }

  blockStartTimestamp = nextBlock;

  return n4; // return the number of frames processed
}

int Heavy_kickdaisy::processInline(float *inputBuffers, float *outputBuffers, int n4) {
  hv_assert(!(n4 & HV_N_SIMD_MASK)); // ensure that n4 is a multiple of HV_N_SIMD

  // define the heavy input buffer for 0 channel(s)
  float **const bIn = NULL;

  // define the heavy output buffer for 2 channel(s)
  float **const bOut = reinterpret_cast<float **>(hv_alloca(2*sizeof(float *)));
  bOut[0] = outputBuffers+(0*n4);
  bOut[1] = outputBuffers+(1*n4);

  int n = process(bIn, bOut, n4);
  return n;
}

int Heavy_kickdaisy::processInlineInterleaved(float *inputBuffers, float *outputBuffers, int n4) {
  hv_assert(n4 & ~HV_N_SIMD_MASK); // ensure that n4 is a multiple of HV_N_SIMD

  // define the heavy input buffer for 0 channel(s), uninterleave
  float *const bIn = NULL;

  // define the heavy output buffer for 2 channel(s)
  float *const bOut = reinterpret_cast<float *>(hv_alloca(2*n4*sizeof(float)));

  int n = processInline(bIn, bOut, n4);

  // interleave the heavy output into the output buffer
  #if HV_SIMD_AVX
  for (int i = 0, j = 0; j < n4; j += 8, i += 16) {
    __m256 x = _mm256_load_ps(bOut+j);    // LLLLLLLL
    __m256 y = _mm256_load_ps(bOut+n4+j); // RRRRRRRR
    __m256 a = _mm256_unpacklo_ps(x, y);  // LRLRLRLR
    __m256 b = _mm256_unpackhi_ps(x, y);  // LRLRLRLR
    _mm256_store_ps(outputBuffers+i, a);
    _mm256_store_ps(outputBuffers+8+i, b);
  }
  #elif HV_SIMD_SSE
  for (int i = 0, j = 0; j < n4; j += 4, i += 8) {
    __m128 x = _mm_load_ps(bOut+j);    // LLLL
    __m128 y = _mm_load_ps(bOut+n4+j); // RRRR
    __m128 a = _mm_unpacklo_ps(x, y);  // LRLR
    __m128 b = _mm_unpackhi_ps(x, y);  // LRLR
    _mm_store_ps(outputBuffers+i, a);
    _mm_store_ps(outputBuffers+4+i, b);
  }
  #elif HV_SIMD_NEON
  // https://community.arm.com/groups/processors/blog/2012/03/13/coding-for-neon--part-5-rearranging-vectors
  for (int i = 0, j = 0; j < n4; j += 4, i += 8) {
    float32x4_t x = vld1q_f32(bOut+j);
    float32x4_t y = vld1q_f32(bOut+n4+j);
    float32x4x2_t z = {x, y};
    vst2q_f32(outputBuffers+i, z); // interleave and store
  }
  #else // HV_SIMD_NONE
  for (int i = 0; i < 2; ++i) {
    for (int j = 0; j < n4; ++j) {
      outputBuffers[i+2*j] = bOut[i*n4+j];
    }
  }
  #endif

  return n;
}
